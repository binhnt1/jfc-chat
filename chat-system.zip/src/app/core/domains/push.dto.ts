export class PushDto {
    ex: string;
    desc: string;
    title: string;
    iOSPushSound: string;
    iOSBadgeCount: boolean;
    operatorUserID: string;
}